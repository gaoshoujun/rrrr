<template>
  <aside>
    上传电子书分为两步：上传电子书和新增电子书。首先需要上传epub电子书文件，服务器会对epub文件进行解析，解析成功后会将电子书的各字段填入表单，之后我们只需要手动点击新增电子书即可完成电子书的保存。查看
    <a
      href="http://www.youbaobao.xyz/mpvue-docs/"
      target="_blank"
    >
      课程官网
    </a>
    获取更多开发指引。
  </aside>
</template>

